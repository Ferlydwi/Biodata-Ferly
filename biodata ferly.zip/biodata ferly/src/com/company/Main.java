package com.company;

public class Main {

    public static void main(String[] args) {
	    String nama="Ferly Dwi Ilmiarani";
	    String jk="Perempuan";
	    String Alt="jalan utomo dua pakijangan wonorejo";
	    String jurusan="RPL";

        System.out.println("Biodata Saya:");
	    System.out.println("_____________");
	    System.out.println("Nama \t\t\t\t :"+nama);
	    System.out.println("Jenis kelamin \t\t :"+jk);
	    System.out.println("Alamat \t\t\t\t :"+Alt);
	    System.out.println("Jurusan \t\t\t :"+jurusan);

    }
}
